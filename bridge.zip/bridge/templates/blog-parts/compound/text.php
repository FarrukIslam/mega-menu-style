
<div class="post_text">
    <?php qode_excerpt(); ?>
</div>