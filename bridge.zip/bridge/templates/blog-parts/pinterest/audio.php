<div class="post_image">
    <audio class="blog_audio" src="<?php echo get_post_meta(get_the_ID(), "audio_link", true) ?>" controls="controls">
        <?php _e("Your browser don't support audio player","qode"); ?>
    </audio>
</div>